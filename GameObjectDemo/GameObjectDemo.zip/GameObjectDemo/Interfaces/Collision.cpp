//
//  Collision.cpp
//  GameObjectDemo
//
//  Created by Alec Lauder on 16/04/2020.
//  Copyright © 2020 Alec Lauder. All rights reserved.
//

#include "Collision.hpp"

// constructor
Collision::Collision(){}

// Destrcutor
Collision::~Collision(){}

// Function to Update collision shape position and check for any
//collisions that occur inside
std::string Collision::UpdateCollider(){
    // would check if any shapes intersect
    // returns name in string if collides
    return "";
}

// Function to set collision shape of the object
void Collision::SetColliderShape(std::string collisionShape){
    // would parse shape and set accordingly
}


